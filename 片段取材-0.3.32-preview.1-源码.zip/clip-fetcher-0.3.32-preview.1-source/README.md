# Shark 0.3.32-preview.1

Shark 在本机按时间范围提取视频片段，支持本地文件和已授权的云盘来源。内置合成示例可以用来验证 MKV 导出和 MP4 工作副本。

安装 Node.js 22+，并将 FFmpeg 和 ffprobe 加入 PATH。运行 `npm start`，打开终端显示的本机地址。在 Mac 上运行 `node --test --test-concurrency=1 test/*.test.mjs` 执行核心回归。测试素材生成需要带 libx264 的 FFmpeg。桌面回归使用 `npm run test:desktop`。

在 Apple Silicon Mac 上运行 `npm run build:mac` 生成桌面包。Windows x64 可以按 [桌面构建说明](desktop/README.md) 构建 Edge 便携包。Mac + Chrome 和 Windows + Edge 均支持迅雷和百度抓链，实际云盘出片需在目标设备上验收。

[试用说明](desktop/同学试用须知.md)包括示例、本地素材和云盘使用方法。
