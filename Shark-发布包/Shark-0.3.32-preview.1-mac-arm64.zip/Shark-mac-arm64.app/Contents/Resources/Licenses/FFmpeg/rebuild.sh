#!/bin/sh
set -eu
cd "$(dirname "$0")"
tar -xf ffmpeg-9.0.2.tar.xz
cd ffmpeg-9.0.2
./configure --prefix="$PWD/output" '--arch=arm64' '--target-os=darwin' '--cc=clang' '--extra-cflags=-arch arm64 -mmacosx-version-min=13.0' '--extra-ldflags=-arch arm64 -mmacosx-version-min=13.0' '--disable-autodetect' '--disable-shared' '--enable-static' '--disable-gpl' '--disable-version3' '--disable-nonfree' '--disable-doc' '--disable-debug' '--disable-programs' '--enable-ffmpeg' '--enable-ffprobe' '--disable-avdevice' '--disable-devices' '--disable-audiotoolbox' '--disable-videotoolbox' '--disable-encoders' '--enable-encoder=aac,wrapped_avframe,pcm_s16le,mjpeg,subrip,ass' '--disable-protocols' '--enable-protocol=file,pipe,http,tcp' '--enable-zlib' '--enable-bzlib' '--enable-pthreads'
make -j8
make install
